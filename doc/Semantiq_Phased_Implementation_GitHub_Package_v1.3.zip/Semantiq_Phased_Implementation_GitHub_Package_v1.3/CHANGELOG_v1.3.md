# SemantIQ v1.3 Changelog

- Merged the existing repository CLAUDE.md and README.md with the v1.2 phase-gated implementation protocol.
- Confirmed Laravel 13/PHP 8.5, React 19, MySQL/cPanel and modular-monolith architecture as the primary application baseline.
- Changed package documentation root from `docs/` to the repository's existing `doc/` path.
- Kept `IMPLEMENTATION_STATUS.md` at repository root.
- Reconciled current single-customer deployment with the product's multi-tenant-ready target architecture.
- Changed current SSO baseline from default multi-tenant SSO to customer-tenant SSO; multi-tenant SSO is a future/enterprise decision.
- Reconciled Git branching: `main` is the only long-lived live-deploy branch; short-lived PR/phase branches are permitted.
- Clarified that Fabric DEV/TEST/PROD workspaces are not Git branches.
- Corrected secret guidance: CI deployment credentials may live in GitHub Environment/Actions secrets; runtime DB/app secrets stay server-side/secret-manager controlled.
- Recorded the current `development` GitHub environment/live-deploy naming mismatch as an item requiring an approved deployment change.
- Preserved the seven-year retention policy as a configurable project baseline, not a hard-coded legal rule.
- Kept legal privacy regime undetermined while making privacy-by-design, data protection and sovereignty engineering controls mandatory.
- Added PHP-stack-aware AI rules: .NET/Python/model-server runtimes require separate sidecar/service approval.
- Preserved the existing design-system template as the sole UI layout/theme authority.
- Added repository-specific conflict-resolution and merge-instruction documents.
- Updated Markdown and Word references to the repository-aligned paths and baseline.
